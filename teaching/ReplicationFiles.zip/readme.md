文件夹中内容如下：
|文件名|文件内容|备注|
|---|---|---|
|report.docx|最终报告||
|questionnaire.docx|问卷|各板块问题与data中编号一致|
|Qualitative_Interview_Record.mx12|预调研定性访谈结果|需用定性研究软件MAXQDA12打开，可删除|
|./src/pycode.ipynb|源代码|需用Jupyter Notebook打开|
|./resources/data.xlsx|问卷数据||
